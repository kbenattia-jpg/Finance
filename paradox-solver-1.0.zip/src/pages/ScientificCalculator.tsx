import React, { useState, useEffect } from 'react';
import { IconCalculator, IconFile, IconSend } from '../components/ui/Icons';

const ScientificCalculator: React.FC = () => {
  const [mode, setMode] = useState<'calc' | 'excel'>('calc');
  
  // --- CALCULATOR STATE ---
  const [display, setDisplay] = useState('');
  const [result, setResult] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  const [copyFeedback, setCopyFeedback] = useState(false);
  const [pasteError, setPasteError] = useState(false);

  // --- EXCEL CONVERTER STATE ---
  const [formulaInput, setFormulaInput] = useState('');
  const [excelOutput, setExcelOutput] = useState('');

  // Gestionnaire global pour Ctrl+V / Cmd+V
  useEffect(() => {
    const handleGlobalPaste = (e: ClipboardEvent) => {
      if (mode === 'calc' && e.clipboardData) {
        // Only intercept in Calc mode if not focused on an input (though here input is div)
        // Check if active element is an input
        const activeTag = document.activeElement?.tagName.toLowerCase();
        if (activeTag === 'textarea' || activeTag === 'input') return;

        e.preventDefault();
        const text = e.clipboardData.getData('text');
        if (text) processPastedText(text);
      }
    };

    window.addEventListener('paste', handleGlobalPaste);
    return () => window.removeEventListener('paste', handleGlobalPaste);
  }, [mode]);

  // --- EXCEL LOGIC ---
  useEffect(() => {
    if (formulaInput.trim() === '') {
        setExcelOutput('');
        return;
    }
    const converted = convertToExcelFR(formulaInput);
    setExcelOutput(converted);
  }, [formulaInput]);

  const convertToExcelFR = (input: string) => {
      let s = input;

      // 1. Clean common copy-paste artifacts
      s = s.replace(/×/g, '*').replace(/÷/g, '/');

      // 2. Finance Functions Mapping (English Code -> French Excel)
      // Order matters to avoid partial replacements
      const financeMap:Record<string, string> = {
          'pmt': 'VPM',
          'rate': 'TAUX',
          'nper': 'NPM',
          'pv': 'VA',
          'fv': 'VC',
          'ipmt': 'INTPER',
          'ppmt': 'PRINCPER',
          'irr': 'TRI',
          'npv': 'VAN'
      };

      // 3. Math Functions Mapping
      const mathMap:Record<string, string> = {
          'sqrt': 'RACINE',
          'average': 'MOYENNE',
          'sum': 'SOMME',
          'if': 'SI',
          'round': 'ARRONDI',
          'abs': 'ABS',
          'max': 'MAX',
          'min': 'MIN',
          'sin': 'SIN',
          'cos': 'COS',
          'tan': 'TAN',
          'log': 'LOG',
          'ln': 'LN',
          'pi': 'PI',
          'power': 'PUISSANCE',
          'mod': 'MOD'
      };

      // Apply Mappings (Case insensitive regex)
      Object.keys(financeMap).forEach(key => {
          const regex = new RegExp(`\\b${key}\\b`, 'gi');
          s = s.replace(regex, financeMap[key]);
      });

      Object.keys(mathMap).forEach(key => {
          const regex = new RegExp(`\\b${key}\\b`, 'gi');
          s = s.replace(regex, mathMap[key]);
      });

      // 4. Separator Conversion (Standard Code -> French Excel)
      // Logic: 
      // - Decimal points (.) become commas (,)
      // - Argument separators (,) become semicolons (;)
      // Strategy: Swap commas to semicolons FIRST, then dots to commas.
      // Limitation: If input string has text like "Hello, World", it breaks. Assuming Math input.
      
      s = s.replace(/,/g, ';'); // Args separator
      s = s.replace(/\./g, ','); // Decimal separator

      // 5. Ensure equals sign
      if (!s.startsWith('=')) s = '=' + s;

      return s;
  };

  const copyExcel = () => {
      navigator.clipboard.writeText(excelOutput);
      setCopyFeedback(true);
      setTimeout(() => setCopyFeedback(false), 2000);
  };


  // --- CALCULATOR LOGIC ---
  const handlePress = (val: string) => {
    setDisplay(prev => prev + val);
  };

  const clear = () => {
    setDisplay('');
    setResult('');
  };

  const backspace = () => {
    setDisplay(prev => {
        if (typeof prev !== 'string') return '';
        return prev.slice(0, -1);
    });
  };

  const handleCopy = async () => {
    const textToCopy = result || display;
    if (textToCopy) {
      try {
        await navigator.clipboard.writeText(textToCopy);
        setCopyFeedback(true);
        setTimeout(() => setCopyFeedback(false), 2000);
      } catch (err) {
        console.error('Failed to copy', err);
      }
    }
  };

  const processPastedText = (text: string) => {
    // 1. Nettoyage basique : garder chiffres, opérateurs, parenthèses, points, virgules, ^, %
    let cleanText = text
        .replace(/\s/g, '') // Enlever les espaces
        .replace(/,/g, '.') // Virgule vers point
        .replace(/[^\d\+\-\*\/\(\)\.\^%eπ]/gi, ''); // Filtrer charactères non mathématiques

    setDisplay(prev => prev + cleanText);
  };

  const handlePasteButton = async () => {
    try {
      setPasteError(false);
      const text = await navigator.clipboard.readText();
      if (text) {
        processPastedText(text);
      }
    } catch (err) {
      console.error('Failed to paste via button', err);
      setPasteError(true);
      setTimeout(() => setPasteError(false), 3000);
    }
  };

  const calculate = () => {
    try {
      // Pré-traitement de l'expression pour la rendre compatible avec JS
      let expression = display
        // Remplacements standards
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/\^/g, '**')
        .replace(/π/g, 'Math.PI')
        .replace(/e/g, 'Math.E')
        // Fonctions
        .replace(/sin\(/g, 'Math.sin(')
        .replace(/cos\(/g, 'Math.cos(')
        .replace(/tan\(/g, 'Math.tan(')
        .replace(/log\(/g, 'Math.log10(')
        .replace(/ln\(/g, 'Math.log(')
        .replace(/√\(/g, 'Math.sqrt(');

      // GESTION DES MULTIPLICATIONS IMPLICITES
      expression = expression.replace(/(\d)(\()/g, '$1*$2');
      expression = expression.replace(/(\))(\d)/g, '$1*$2');
      expression = expression.replace(/(\d)(Math)/g, '$1*$2');
      expression = expression.replace(/(\))(\()/g, '$1*$2');

      // eslint-disable-next-line no-eval
      const res = eval(expression);
      
      let formattedRes = res;
      if (!Number.isInteger(res)) {
          if (Math.abs(res) < 0.0001 || Math.abs(res) > 1e9) {
              formattedRes = res.toExponential(4);
          } else {
              formattedRes = parseFloat(res.toFixed(6)); 
          }
      }
      
      setResult(formattedRes.toString());
      setHistory(prev => [`${display} = ${formattedRes}`, ...prev.slice(0, 9)]);
    } catch (e) {
      setResult('Erreur de syntaxe');
    }
  };

  // Styles
  const btnClass = "h-12 md:h-14 rounded-lg font-bold text-lg transition-all active:scale-95 shadow-sm flex items-center justify-center select-none";
  const numClass = `${btnClass} bg-white text-royal-900 hover:bg-royal-50 border border-royal-100`;
  const opClass = `${btnClass} bg-royal-100 text-royal-800 hover:bg-royal-200 border border-royal-200`;
  const fnClass = `${btnClass} bg-royal-700 text-white hover:bg-royal-600 border border-royal-600 font-mono text-base`;
  const actionClass = `${btnClass} bg-gold-500 text-white hover:bg-gold-400 border border-gold-400`;

  return (
    <div className="p-4 md:p-8 bg-royal-50 h-full overflow-y-auto flex flex-col items-center">
      <div className="w-full max-w-lg">
        
        {/* Header & Tabs */}
        <div className="flex flex-col items-center mb-6 space-y-4">
             <h1 className="text-2xl font-bold text-royal-900 flex items-center gap-2">
                <IconCalculator className="w-6 h-6 text-gold-500" />
                Outils Mathématiques
            </h1>
            <div className="flex bg-white p-1 rounded-xl shadow-sm border border-royal-200">
                <button 
                    onClick={() => setMode('calc')}
                    className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${mode === 'calc' ? 'bg-royal-800 text-white shadow-md' : 'text-royal-500 hover:text-royal-800'}`}
                >
                    Calculatrice
                </button>
                <button 
                    onClick={() => setMode('excel')}
                    className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${mode === 'excel' ? 'bg-emerald-600 text-white shadow-md' : 'text-royal-500 hover:text-emerald-600'}`}
                >
                    <span>Excel Converter</span>
                    <span className="bg-emerald-100 text-emerald-800 text-[9px] px-1.5 rounded-full">Pro</span>
                </button>
            </div>
        </div>

        {/* --- CALCULATOR MODE --- */}
        {mode === 'calc' && (
            <div className="animate-fadeIn w-full">
                {/* Display Screen */}
                <div className="bg-royal-900 p-6 rounded-2xl shadow-premium mb-6 text-right border-4 border-royal-800 relative overflow-hidden group">
                
                {/* Copy/Paste Tools */}
                <div className="absolute top-3 left-3 flex gap-2 opacity-100 transition-opacity z-10">
                    <button 
                        onClick={handleCopy} 
                        className="bg-royal-800 hover:bg-royal-700 text-royal-200 text-xs px-2 py-1 rounded border border-royal-700 flex items-center gap-1 transition-colors"
                    >
                        {copyFeedback ? (
                            <span className="text-emerald-400 font-bold">Copié !</span>
                        ) : (
                            <>COPIER</>
                        )}
                    </button>
                    <button 
                        onClick={handlePasteButton} 
                        className="bg-royal-800 hover:bg-royal-700 text-royal-200 text-xs px-2 py-1 rounded border border-royal-700 flex items-center gap-1 transition-colors relative"
                    >
                        COLLER
                        {pasteError && (
                        <div className="absolute left-0 -bottom-8 bg-red-500 text-white text-[10px] p-1 rounded whitespace-nowrap shadow-lg">
                            Bloqué? Utilisez Ctrl+V
                        </div>
                        )}
                    </button>
                </div>

                <div className="text-royal-300 text-sm h-6 font-mono overflow-hidden whitespace-nowrap mb-1 mt-4">
                    {history.length > 0 ? history[0] : ''}
                </div>
                <div className="text-white text-3xl md:text-4xl font-mono tracking-wider overflow-x-auto whitespace-nowrap scrollbar-hide h-12 flex items-center justify-end">
                    {display || '0'}
                </div>
                <div className="text-gold-400 text-xl md:text-2xl font-bold h-8 mt-2">
                    {result ? `= ${result}` : ''}
                </div>
                </div>

                {/* Keypad */}
                <div className="grid grid-cols-5 gap-2 md:gap-3">
                    {/* Scientific Functions */}
                    <button onClick={() => handlePress('sin(')} className={fnClass}>sin</button>
                    <button onClick={() => handlePress('cos(')} className={fnClass}>cos</button>
                    <button onClick={() => handlePress('tan(')} className={fnClass}>tan</button>
                    <button onClick={() => handlePress('(')} className={fnClass}>({/* */}</button>
                    <button onClick={() => handlePress(')')} className={fnClass}>){/* */}</button>

                    <button onClick={() => handlePress('log(')} className={fnClass}>log</button>
                    <button onClick={() => handlePress('ln(')} className={fnClass}>ln</button>
                    <button onClick={() => handlePress('^')} className={fnClass}>x^y</button>
                    <button onClick={() => handlePress('√(')} className={fnClass}>√</button>
                    <button onClick={() => handlePress('e')} className={fnClass}>e</button>

                    {/* Numpad & Ops */}
                    <button onClick={clear} className={`${btnClass} bg-red-100 text-red-600 border-red-200`}>AC</button>
                    <button onClick={backspace} className={`${btnClass} bg-royal-100 text-royal-600`}>⌫</button>
                    <button onClick={() => handlePress('%')} className={opClass}>%</button>
                    <button onClick={() => handlePress('÷')} className={opClass}>÷</button>
                    <button onClick={() => handlePress('π')} className={fnClass}>π</button>

                    <button onClick={() => handlePress('7')} className={numClass}>7</button>
                    <button onClick={() => handlePress('8')} className={numClass}>8</button>
                    <button onClick={() => handlePress('9')} className={numClass}>9</button>
                    <button onClick={() => handlePress('×')} className={opClass}>×</button>
                    <button onClick={() => handlePress('^2')} className={fnClass}>x²</button>

                    <button onClick={() => handlePress('4')} className={numClass}>4</button>
                    <button onClick={() => handlePress('5')} className={numClass}>5</button>
                    <button onClick={() => handlePress('6')} className={numClass}>6</button>
                    <button onClick={() => handlePress('-')} className={opClass}>-</button>
                    <button onClick={() => handlePress('10^')} className={fnClass}>10^x</button>

                    <button onClick={() => handlePress('1')} className={numClass}>1</button>
                    <button onClick={() => handlePress('2')} className={numClass}>2</button>
                    <button onClick={() => handlePress('3')} className={numClass}>3</button>
                    <button onClick={() => handlePress('+')} className={opClass}>+</button>
                    <button onClick={() => handlePress('1/')} className={fnClass}>1/x</button>

                    <button onClick={() => handlePress('0')} className={`${numClass} col-span-2`}>0</button>
                    <button onClick={() => handlePress('.')} className={numClass}>.</button>
                    <button onClick={calculate} className={`${actionClass} col-span-2 shadow-lg shadow-gold-500/30`}>=</button>
                </div>

                 {/* History Log */}
                <div className="mt-8 bg-white rounded-xl p-4 border border-royal-100 shadow-inner h-32 overflow-y-auto text-xs font-mono">
                    <div className="text-royal-400 font-bold mb-2 uppercase tracking-wider">Historique</div>
                    {history.map((h, i) => (
                        <div key={i} className="py-1 border-b border-royal-50 text-royal-700">{h}</div>
                    ))}
                </div>
            </div>
        )}

        {/* --- EXCEL CONVERTER MODE --- */}
        {mode === 'excel' && (
            <div className="animate-fadeIn w-full space-y-6">
                <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 text-sm text-emerald-800 shadow-sm">
                    <strong>Convertisseur Formule → Excel FR</strong><br/>
                    Collez une formule mathématique (ex: `pmt(0.05, 12, 1000)` ou `sqrt(100)`).<br/>
                    Je traduis les fonctions et adapte les séparateurs (`;`) pour Excel Maroc/France.
                </div>

                {/* Input Area */}
                <div className="space-y-2">
                    <label className="text-xs font-bold text-royal-500 uppercase tracking-wider">Formule Standard / Code</label>
                    <textarea 
                        value={formulaInput}
                        onChange={(e) => setFormulaInput(e.target.value)}
                        placeholder="Ex: PMT(5%/12, 120, 200000) ou sqrt(25) + 10"
                        className="w-full p-4 h-32 rounded-xl border border-royal-200 bg-white font-mono text-royal-900 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none resize-none shadow-inner text-sm"
                    />
                </div>

                {/* Output Area */}
                <div className="space-y-2 relative">
                    <label className="text-xs font-bold text-emerald-600 uppercase tracking-wider">Résultat Excel (Copier-Coller)</label>
                    <div className="w-full p-4 h-32 rounded-xl border-2 border-emerald-100 bg-emerald-900/5 font-mono text-royal-900 flex items-center justify-center text-center relative overflow-hidden">
                        {excelOutput ? (
                            <span className="font-bold text-emerald-900 break-all">{excelOutput}</span>
                        ) : (
                            <span className="text-royal-400 italic text-sm">Le résultat apparaîtra ici...</span>
                        )}
                        
                        {/* Copy Button */}
                        {excelOutput && (
                            <button 
                                onClick={copyExcel}
                                className="absolute top-2 right-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs px-3 py-1.5 rounded-lg shadow-sm transition-all flex items-center gap-1"
                            >
                                {copyFeedback ? 'Copié !' : 'Copier'}
                            </button>
                        )}
                    </div>
                </div>

                {/* Legend */}
                <div className="grid grid-cols-2 gap-4 text-[10px] text-royal-400">
                    <div className="bg-white p-2 rounded border border-royal-100">
                        <strong className="block mb-1 text-royal-600">Mappage Financier</strong>
                        PMT → VPM<br/>
                        PV → VA<br/>
                        FV → VC<br/>
                        IRR → TRI
                    </div>
                    <div className="bg-white p-2 rounded border border-royal-100">
                        <strong className="block mb-1 text-royal-600">Mappage Structurel</strong>
                        . (décimale) → ,<br/>
                        , (séparateur) → ;<br/>
                        sqrt → RACINE
                    </div>
                </div>
            </div>
        )}

      </div>
    </div>
  );
};

export default ScientificCalculator;