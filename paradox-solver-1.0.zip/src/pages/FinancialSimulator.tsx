import React, { useState, useEffect } from 'react';
import ChartRenderer from '../components/ui/ChartRenderer';
import { IconCalculator } from '../components/ui/Icons';

const FinancialSimulator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'loan' | 'investment' | 'roi'>('loan');
  
  // Loan State
  const [loanAmount, setLoanAmount] = useState(250000);
  const [loanRate, setLoanRate] = useState(4.5);
  const [loanDuration, setLoanDuration] = useState(20); // Years
  const [loanInsurance, setLoanInsurance] = useState(0.3); // %
  const [loanResults, setLoanResults] = useState<any>(null);

  // Investment State
  const [investInitial, setInvestInitial] = useState(50000);
  const [investMonthly, setInvestMonthly] = useState(1000);
  const [investRate, setInvestRate] = useState(3.5);
  const [investDuration, setInvestDuration] = useState(10);
  const [investResults, setInvestResults] = useState<any>(null);

  // ROI Expert State
  const [roiInitialCost, setRoiInitialCost] = useState(100000); // Investissement Initial (Capex)
  const [roiAnnualRevenue, setRoiAnnualRevenue] = useState(45000); // Cash Flow Annuel estimé
  const [roiDurationYears, setRoiDurationYears] = useState(5); // Durée du projet
  const [roiDiscountRate, setRoiDiscountRate] = useState(10); // Taux d'actualisation (WACC)
  const [roiResults, setRoiResults] = useState<any>(null);

  // --- LOAN CALCULATOR LOGIC ---
  const calculateLoan = () => {
    const P = loanAmount;
    const r = loanRate / 100 / 12; // Monthly rate
    const n = loanDuration * 12; // Total months
    const insuranceMonthly = P * (loanInsurance / 100) / 12;

    // Mensualité (Hors Assurance)
    // M = P * (r * (1+r)^n) / ((1+r)^n - 1)
    let monthlyPayment = 0;
    if (r > 0) {
      monthlyPayment = P * (r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    } else {
      monthlyPayment = P / n;
    }

    const monthlyTotal = monthlyPayment + insuranceMonthly;
    const totalCost = (monthlyTotal * n) - P;

    // Generate Amortization Schedule Data for Chart
    const data = [];
    let balance = P;
    let interestSum = 0;
    let capitalSum = 0;

    // We take sample points to avoid crashing the chart with 300 points
    const step = n > 60 ? Math.floor(n / 20) : 1;

    for (let i = 1; i <= n; i++) {
      const interest = balance * r;
      const capital = monthlyPayment - interest;
      balance -= capital;
      if (balance < 0) balance = 0;
      
      interestSum += interest;
      capitalSum += capital;

      if (i % step === 0 || i === n) {
        data.push({
          name: `M${i}`,
          Capital: Math.round(capitalSum),
          Intérêts: Math.round(interestSum),
          Restant: Math.round(balance)
        });
      }
    }

    setLoanResults({
      monthlyPayment: monthlyPayment.toFixed(2),
      monthlyTotal: monthlyTotal.toFixed(2),
      totalCost: totalCost.toFixed(2),
      chartData: data
    });
  };

  // --- INVESTMENT CALCULATOR LOGIC ---
  const calculateInvestment = () => {
    const P = investInitial;
    const PMT = investMonthly;
    const r = investRate / 100 / 12;
    const n = investDuration * 12;

    // Future Value formula with compound interest + regular deposits
    // FV = P * (1+r)^n + PMT * [((1+r)^n - 1) / r]
    let fv = 0;
    let totalInvested = P + (PMT * n);

    const data = [];
    let currentVal = P;
    const step = n > 60 ? Math.floor(n / 20) : 1;

    for (let i = 0; i <= n; i++) {
      if (i > 0) {
        // Apply interest
        currentVal = currentVal * (1 + r);
        // Add deposit
        currentVal += PMT;
      }
      
      if (i % step === 0 || i === n) {
        data.push({
          name: `A${Math.floor(i/12)}`,
          TotalInvesti: Math.round(P + (PMT * i)),
          InteretsGeneres: Math.round(currentVal - (P + (PMT * i))),
          ValeurTotale: Math.round(currentVal)
        });
      }
    }
    
    fv = currentVal;
    
    setInvestResults({
      totalValue: fv.toFixed(2),
      interestEarned: (fv - totalInvested).toFixed(2),
      totalInvested: totalInvested.toFixed(2),
      chartData: data
    });
  };

  // --- ROI EXPERT CALCULATOR LOGIC (VAN, TRI, Payback) ---
  const calculateROIExpert = () => {
     if (roiInitialCost === 0) return;

     const cf = roiAnnualRevenue; // Cash Flow Annuel Constant (simplification pour UX)
     const rate = roiDiscountRate / 100;
     const n = roiDurationYears;
     const initial = roiInitialCost;

     let van = -initial; // Valeur Actuelle Nette
     let cumulativeCashFlow = -initial;
     let paybackYear = -1;
     const chartData = [];

     // Point 0 (Investissement)
     chartData.push({
         name: 'Départ',
         FluxCumule: -initial,
         Seuil: 0
     });

     for (let t = 1; t <= n; t++) {
         // VAN Calculation
         const discountedCF = cf / Math.pow(1 + rate, t);
         van += discountedCF;

         // Payback Calculation (Flux non actualisés pour Payback simple, ou actualisés pour Payback actualisé. 
         // Standard business often uses simple payback, but expert uses discounted. Let's show Simple Flow for visual).
         cumulativeCashFlow += cf;

         if (paybackYear === -1 && cumulativeCashFlow >= 0) {
            // Linear interpolation for more precise payback
            const prevBalance = cumulativeCashFlow - cf;
            const fraction = Math.abs(prevBalance) / cf;
            paybackYear = (t - 1) + fraction;
         }

         chartData.push({
             name: `Année ${t}`,
             FluxCumule: Math.round(cumulativeCashFlow),
             FluxActualiseCumule: Math.round(van),
             Seuil: 0
         });
     }

     // TRI Calculation (Approximation Newton)
     // 0 = -Initial + Sum(CF / (1+IRR)^t)
     // Approximation simple si CF constant: Initial = CF * ((1 - (1+IRR)^-n) / IRR)
     let irr = 0;
     let low = -0.5;
     let high = 5.0; // 500% max
     for(let i=0; i<50; i++) {
        const mid = (low + high) / 2;
        let npv_mid = -initial;
        for(let t=1; t<=n; t++) npv_mid += cf / Math.pow(1 + mid, t);
        
        if(npv_mid > 0) low = mid;
        else high = mid;
     }
     irr = (low + high) / 2 * 100;


     // ROI Global Simple (Total Gain / Cost)
     const totalGain = (cf * n);
     const roiGlobal = ((totalGain - initial) / initial) * 100;

     setRoiResults({
         van: van.toFixed(2),
         tri: irr.toFixed(2),
         payback: paybackYear > 0 ? paybackYear.toFixed(1) : '> ' + n,
         roiGlobal: roiGlobal.toFixed(2),
         profitNet: (totalGain - initial).toFixed(2),
         chartData: chartData
     });
  };

  useEffect(() => {
    calculateLoan();
  }, [loanAmount, loanRate, loanDuration, loanInsurance]);

  useEffect(() => {
    calculateInvestment();
  }, [investInitial, investMonthly, investRate, investDuration]);

  useEffect(() => {
    calculateROIExpert();
  }, [roiInitialCost, roiAnnualRevenue, roiDurationYears, roiDiscountRate]);

  return (
    <div className="p-6 md:p-10 bg-royal-50 h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <h1 className="text-3xl font-bold text-royal-900 flex items-center gap-3">
            <IconCalculator className="w-8 h-8 text-gold-500" />
            Simulateur Financier
            </h1>
            <div className="bg-white border border-royal-200 text-royal-500 text-xs px-3 py-1 rounded-full font-mono mt-2 md:mt-0 shadow-sm">
            Norme Bancaire : <strong className="text-royal-800">Base 360 jours</strong>
            </div>
        </div>

        {/* Tabs */}
        <div className="flex space-x-2 md:space-x-4 mb-8 overflow-x-auto pb-2">
          <button
            onClick={() => setActiveTab('loan')}
            className={`px-4 md:px-6 py-3 rounded-lg font-bold transition-all whitespace-nowrap ${
              activeTab === 'loan'
                ? 'bg-royal-800 text-white shadow-premium'
                : 'bg-white text-royal-600 hover:bg-royal-100'
            }`}
          >
            Crédit Immobilier
          </button>
          <button
            onClick={() => setActiveTab('investment')}
            className={`px-4 md:px-6 py-3 rounded-lg font-bold transition-all whitespace-nowrap ${
              activeTab === 'investment'
                ? 'bg-royal-800 text-white shadow-premium'
                : 'bg-white text-royal-600 hover:bg-royal-100'
            }`}
          >
            Épargne & Placement
          </button>
          <button
            onClick={() => setActiveTab('roi')}
            className={`px-4 md:px-6 py-3 rounded-lg font-bold transition-all whitespace-nowrap flex items-center gap-2 ${
              activeTab === 'roi'
                ? 'bg-royal-800 text-white shadow-premium'
                : 'bg-white text-royal-600 hover:bg-royal-100'
            }`}
          >
            <span>ROI Expert (VAN/TRI)</span>
            {activeTab !== 'roi' && <span className="bg-gold-500 text-white text-[9px] px-1.5 py-0.5 rounded-full">NEW</span>}
          </button>
        </div>

        {/* LOAN SECTION */}
        {activeTab === 'loan' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-fadeIn">
            <div className="bg-white p-6 rounded-2xl shadow-card border border-royal-100 h-fit">
              <h3 className="text-xl font-bold text-royal-800 mb-6">Paramètres du Prêt</h3>
              
              <div className="space-y-5">
                <div>
                  <label className="block text-sm font-semibold text-royal-600 mb-2">Montant (MAD)</label>
                  <input type="number" value={loanAmount} onChange={(e) => setLoanAmount(Number(e.target.value))} className="w-full p-3 bg-royal-50 border border-royal-200 rounded-lg text-royal-900 font-mono focus:border-gold-500 focus:ring-1 focus:ring-gold-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-royal-600 mb-2">Taux d'intérêt (%)</label>
                  <input type="number" step="0.1" value={loanRate} onChange={(e) => setLoanRate(Number(e.target.value))} className="w-full p-3 bg-royal-50 border border-royal-200 rounded-lg text-royal-900 font-mono focus:border-gold-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-royal-600 mb-2">Durée (Années)</label>
                  <input type="range" min="1" max="30" value={loanDuration} onChange={(e) => setLoanDuration(Number(e.target.value))} className="w-full accent-gold-500" />
                  <div className="text-right text-sm text-royal-500 font-mono">{loanDuration} ans</div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-royal-600 mb-2">Assurance (%)</label>
                  <input type="number" step="0.1" value={loanInsurance} onChange={(e) => setLoanInsurance(Number(e.target.value))} className="w-full p-3 bg-royal-50 border border-royal-200 rounded-lg text-royal-900 font-mono focus:border-gold-500 outline-none" />
                </div>
              </div>
            </div>

            <div className="lg:col-span-2 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-royal-800 text-white p-6 rounded-xl shadow-premium">
                   <div className="text-royal-300 text-sm font-medium mb-1">Mensualité (TTC)</div>
                   <div className="text-3xl font-bold font-mono text-gold-400">{loanResults?.monthlyTotal} <span className="text-sm">DH</span></div>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-card border border-royal-100">
                   <div className="text-royal-500 text-sm font-medium mb-1">Coût Total Crédit</div>
                   <div className="text-2xl font-bold font-mono text-royal-800">{loanResults?.totalCost} <span className="text-sm">DH</span></div>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-card border border-royal-100">
                   <div className="text-royal-500 text-sm font-medium mb-1">Total à Rembourser</div>
                   <div className="text-2xl font-bold font-mono text-royal-800">{(Number(loanResults?.totalCost) + loanAmount).toFixed(2)} <span className="text-sm">DH</span></div>
                </div>
              </div>

              {loanResults?.chartData && (
                 <ChartRenderer 
                    type="area" 
                    title="Amortissement du Capital vs Intérêts" 
                    data={loanResults.chartData} 
                    dataKeys={['Capital', 'Intérêts']} 
                  />
              )}
            </div>
          </div>
        )}

        {/* INVESTMENT SECTION */}
        {activeTab === 'investment' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-fadeIn">
             <div className="bg-white p-6 rounded-2xl shadow-card border border-royal-100 h-fit">
              <h3 className="text-xl font-bold text-royal-800 mb-6">Plan d'Épargne</h3>
              <div className="space-y-5">
                <div>
                  <label className="block text-sm font-semibold text-royal-600 mb-2">Versement Initial (MAD)</label>
                  <input type="number" value={investInitial} onChange={(e) => setInvestInitial(Number(e.target.value))} className="w-full p-3 bg-royal-50 border border-royal-200 rounded-lg text-royal-900 font-mono focus:border-gold-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-royal-600 mb-2">Versement Mensuel (MAD)</label>
                  <input type="number" value={investMonthly} onChange={(e) => setInvestMonthly(Number(e.target.value))} className="w-full p-3 bg-royal-50 border border-royal-200 rounded-lg text-royal-900 font-mono focus:border-gold-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-royal-600 mb-2">Rendement Annuel (%)</label>
                  <input type="number" step="0.1" value={investRate} onChange={(e) => setInvestRate(Number(e.target.value))} className="w-full p-3 bg-royal-50 border border-royal-200 rounded-lg text-royal-900 font-mono focus:border-gold-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-royal-600 mb-2">Horizon (Années)</label>
                  <input type="range" min="1" max="40" value={investDuration} onChange={(e) => setInvestDuration(Number(e.target.value))} className="w-full accent-gold-500" />
                  <div className="text-right text-sm text-royal-500 font-mono">{investDuration} ans</div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-2 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-royal-800 text-white p-6 rounded-xl shadow-premium">
                   <div className="text-royal-300 text-sm font-medium mb-1">Capital Final</div>
                   <div className="text-3xl font-bold font-mono text-gold-400">{investResults?.totalValue} <span className="text-sm">DH</span></div>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-card border border-royal-100">
                   <div className="text-royal-500 text-sm font-medium mb-1">Intérêts Générés</div>
                   <div className="text-2xl font-bold font-mono text-emerald-600">+{investResults?.interestEarned} <span className="text-sm">DH</span></div>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-card border border-royal-100">
                   <div className="text-royal-500 text-sm font-medium mb-1">Total Versé</div>
                   <div className="text-2xl font-bold font-mono text-royal-800">{investResults?.totalInvested} <span className="text-sm">DH</span></div>
                </div>
              </div>

              {investResults?.chartData && (
                 <ChartRenderer 
                    type="area" 
                    title="Projection de la Valeur Acquise" 
                    data={investResults.chartData} 
                    dataKeys={['TotalInvesti', 'InteretsGeneres']} 
                  />
              )}
            </div>
          </div>
        )}

        {/* ROI EXPERT SECTION (UPDATED) */}
        {activeTab === 'roi' && (
           <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-fadeIn">
             <div className="bg-white p-6 rounded-2xl shadow-card border border-royal-100 h-fit">
              <h3 className="text-xl font-bold text-royal-800 mb-6">Paramètres d'Investissement</h3>
              <div className="space-y-5">
                <div>
                  <label className="block text-sm font-semibold text-royal-600 mb-2">Coût Initial (Capex) - MAD</label>
                  <input type="number" value={roiInitialCost} onChange={(e) => setRoiInitialCost(Number(e.target.value))} className="w-full p-3 bg-royal-50 border border-royal-200 rounded-lg text-royal-900 font-mono focus:border-gold-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-royal-600 mb-2">Cash Flow Annuel Estimé (MAD)</label>
                  <input type="number" value={roiAnnualRevenue} onChange={(e) => setRoiAnnualRevenue(Number(e.target.value))} className="w-full p-3 bg-royal-50 border border-royal-200 rounded-lg text-royal-900 font-mono focus:border-gold-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-royal-600 mb-2">Durée du Projet (Années)</label>
                  <input type="range" min="1" max="20" value={roiDurationYears} onChange={(e) => setRoiDurationYears(Number(e.target.value))} className="w-full accent-gold-500" />
                  <div className="text-right text-sm text-royal-500 font-mono">{roiDurationYears} ans</div>
                </div>
                 <div>
                  <label className="block text-sm font-semibold text-royal-600 mb-2 flex justify-between">
                     <span>Taux d'Actualisation (Risque)</span>
                     <span className="text-xs text-royal-400 font-normal">Standard: 8-12%</span>
                  </label>
                  <input type="number" step="0.5" value={roiDiscountRate} onChange={(e) => setRoiDiscountRate(Number(e.target.value))} className="w-full p-3 bg-royal-50 border border-royal-200 rounded-lg text-royal-900 font-mono focus:border-gold-500 outline-none" />
                </div>
              </div>
            </div>

             <div className="lg:col-span-2 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                
                {/* VAN Card */}
                <div className={`p-5 rounded-xl shadow-card border border-royal-100 ${Number(roiResults?.van) > 0 ? 'bg-white' : 'bg-red-50 border-red-100'}`}>
                   <div className="text-royal-500 text-xs font-bold uppercase tracking-wider mb-2">VAN (Valeur Actuelle Nette)</div>
                   <div className={`text-xl font-bold font-mono ${Number(roiResults?.van) >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                      {roiResults?.van} <span className="text-xs">DH</span>
                   </div>
                   <div className="text-[10px] text-royal-400 mt-2 leading-tight">
                      {Number(roiResults?.van) > 0 ? "Projet créateur de valeur." : "Projet destructeur de valeur."}
                   </div>
                </div>

                {/* TRI Card */}
                <div className="bg-white p-5 rounded-xl shadow-card border border-royal-100">
                   <div className="text-royal-500 text-xs font-bold uppercase tracking-wider mb-2">TRI (Taux Interne)</div>
                   <div className="text-xl font-bold font-mono text-royal-800">
                      {roiResults?.tri} %
                   </div>
                   <div className="text-[10px] text-royal-400 mt-2 leading-tight">
                      Rentabilité intrinsèque du projet.
                   </div>
                </div>

                {/* Payback Card */}
                <div className="bg-white p-5 rounded-xl shadow-card border border-royal-100">
                   <div className="text-royal-500 text-xs font-bold uppercase tracking-wider mb-2">Délai Récupération</div>
                   <div className="text-xl font-bold font-mono text-gold-600">
                      {roiResults?.payback} <span className="text-xs">Ans</span>
                   </div>
                   <div className="text-[10px] text-royal-400 mt-2 leading-tight">
                      Temps pour "Break-even".
                   </div>
                </div>

                 {/* ROI Simple Card */}
                 <div className="bg-royal-800 text-white p-5 rounded-xl shadow-premium">
                   <div className="text-royal-300 text-xs font-bold uppercase tracking-wider mb-2">ROI Global</div>
                   <div className="text-xl font-bold font-mono text-gold-400">
                      {roiResults?.roiGlobal} %
                   </div>
                   <div className="text-[10px] text-royal-300 mt-2 leading-tight">
                      Rentabilité brute sur {roiDurationYears} ans.
                   </div>
                </div>

              </div>

               {roiResults?.chartData && (
                 <ChartRenderer 
                    type="area" 
                    title="Courbe de Trésorerie Cumulée (J-Curve)" 
                    data={roiResults.chartData} 
                    dataKeys={['FluxCumule', 'Seuil']} 
                  />
              )}
              
              <div className="bg-royal-50 p-4 rounded-lg border border-royal-100 text-sm text-royal-600 space-y-2">
                  <p><strong>Note Expert :</strong></p>
                  <ul className="list-disc ml-4 space-y-1 text-xs">
                      <li>La <strong>VAN</strong> actualise les flux futurs. Une VAN positive signifie que le projet est rentable par rapport au taux d'actualisation choisi ({roiDiscountRate}%).</li>
                      <li>Le <strong>TRI</strong> est le taux pour lequel la VAN est nulle. Si TRI &gt; {roiDiscountRate}%, c'est bon signe.</li>
                      <li>La courbe montre le point mort (lorsque la ligne bleue traverse la ligne 0).</li>
                  </ul>
              </div>
            </div>
           </div>
        )}
      </div>
    </div>
  );
};

export default FinancialSimulator;