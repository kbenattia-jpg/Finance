import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import MainLayout from './layouts/MainLayout';
import Dashboard from './pages/Dashboard';
import SolverChat from './pages/SolverChat';
import FinancialSimulator from './pages/FinancialSimulator';
import ScientificCalculator from './pages/ScientificCalculator';

const App: React.FC = () => {
  return (
    <Router>
      <MainLayout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/solver" element={<SolverChat />} />
          <Route path="/simulator" element={<FinancialSimulator />} />
          <Route path="/calculator" element={<ScientificCalculator />} />
        </Routes>
      </MainLayout>
    </Router>
  );
};

export default App;