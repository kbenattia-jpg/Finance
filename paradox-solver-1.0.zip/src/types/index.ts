export enum Role {
  USER = 'user',
  MODEL = 'model'
}

export interface ChatMessage {
  id: string;
  role: Role;
  text: string;
  timestamp: Date;
  images?: string[]; // Base64 strings
  chartData?: any[]; // JSON data for charts (Must be an Array)
  chartType?: 'line' | 'bar' | 'area' | 'pie';
  chartTitle?: string;
  tableData?: { headers: string[], rows: (string|number)[][] }; // Added for structured tables
  isThinking?: boolean;
}

export interface MacroIndicator {
  label: string;
  value: string;
  trend: 'up' | 'down' | 'stable';
  description: string;
}

export interface SimulationParams {
  amount: number;
  rate: number;
  duration: number; // in months
  type: 'amortissement_constant' | 'annuite_constante';
}

export interface DashboardStat {
  title: string;
  value: string;
  change: string;
  isPositive: boolean;
}