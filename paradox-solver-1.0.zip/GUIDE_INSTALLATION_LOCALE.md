
# Guide d'Installation Locale & Configuration API
**Réalisé par BENATTIA KARIM**

Ce guide explique comment installer l'application sur votre poste, configurer la clé API Google (gratuite), et préparer la conversion en fichier exécutable `.exe`.

---

## 1. Création de la Clé API (Obligatoire pour l'IA)

Pour que l'intelligence artificielle fonctionne, vous avez besoin d'une clé Google Gemini.

1.  Rendez-vous sur **[Google AI Studio](https://aistudio.google.com/app/apikey)**.
2.  Connectez-vous avec votre compte Google.
3.  Cliquez sur le bouton bleu **"Create API key"**.
4.  Si demandé, choisissez "Create API key in new project".
5.  Copiez la clé générée (elle commence par `AIza...`).

---

## 2. Configuration du Fichier `.env` (Critique)

Pour que l'application détecte cette clé sans serveur, nous utilisons un fichier de variables d'environnement.

1.  Allez à la **racine** de votre dossier de projet (là où se trouve `package.json`).
2.  Créez un nouveau fichier texte.
3.  **Renommez-le exactement** en : `.env`
    *   ⚠️ **Attention :** Il ne doit PAS s'appeler `.env.txt`. Si Windows masque les extensions, assurez-vous de vérifier le type de fichier.
4.  Ouvrez ce fichier `.env` avec le Bloc-notes.
5.  Collez la ligne suivante (remplacez par votre clé) :

```properties
REACT_APP_API_KEY=AIzaSy...VOTRE_CLE_COPIEE_ICI
```

> **Note technique :** Le préfixe `REACT_APP_` est **obligatoire**. Sans lui, l'application ignorera votre clé par sécurité.

---

## 3. Installation et Lancement

### Prérequis
*   [Node.js](https://nodejs.org/) (Version LTS recommandée) installé sur votre machine.

### Commandes
Ouvrez un terminal dans le dossier du projet :

1.  **Installer les dépendances :**
    ```bash
    npm install
    ```

2.  **Lancer l'application (Mode Dev) :**
    ```bash
    npm start
    ```
    L'application s'ouvrira sur `http://localhost:3000`.

---

## 4. Création de l'Exécutable (.exe)

Pour transformer ce site web en logiciel Windows autonome :

1.  **Construire le projet :**
    ```bash
    npm run build
    ```

2.  **Configurer Electron (main.js) :**
    Créez un fichier `main.js` à la racine :
    ```javascript
    const { app, BrowserWindow } = require('electron');
    const path = require('path');

    function createWindow() {
      const win = new BrowserWindow({
        width: 1280,
        height: 800,
        title: "Paradox Solver",
        webPreferences: { nodeIntegration: true }
      });
      
      // Charge le fichier construit
      win.loadFile(path.join(__dirname, 'build/index.html'));
    }

    app.whenReady().then(createWindow);
    ```

3.  **Empaqueter :**
    Utilisez une commande comme `electron-builder` (nécessite une configuration supplémentaire dans package.json) pour générer le `.exe` final dans un dossier `dist`.
