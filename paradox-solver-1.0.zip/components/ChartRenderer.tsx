import React from 'react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell
} from 'recharts';

interface ChartProps {
  data: any[];
  type: 'line' | 'bar' | 'area' | 'pie';
  title?: string;
  dataKeys?: string[];
}

// Royal Navy & Gold Palette
const COLORS = ['#d4af37', '#102a43', '#334e68', '#b8860b', '#829ab1'];

const ChartRenderer: React.FC<ChartProps> = ({ data, type, title, dataKeys = ['value'] }) => {
  // CRITICAL FIX: Recharts crashes with "t.slice is not a function" if data is not an array.
  // We strictly check for Array type here.
  if (!data || !Array.isArray(data) || data.length === 0) return null;

  const renderChart = () => {
    switch (type) {
      case 'bar':
        return (
          <BarChart data={data} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
            <XAxis dataKey="name" stroke="#64748b" tick={{fontSize: 12}} />
            <YAxis stroke="#64748b" tick={{fontSize: 12}} />
            <Tooltip 
              contentStyle={{ backgroundColor: '#fff', borderColor: '#e2e8f0', color: '#102a43', borderRadius: '8px', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }}
            />
            <Legend wrapperStyle={{paddingTop: '10px'}} />
            {dataKeys.map((key, index) => (
              <Bar key={key} dataKey={key} fill={COLORS[index % COLORS.length]} radius={[4, 4, 0, 0]} />
            ))}
          </BarChart>
        );
      case 'area':
        return (
          <AreaChart data={data} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
            <XAxis dataKey="name" stroke="#64748b" tick={{fontSize: 12}} />
            <YAxis stroke="#64748b" tick={{fontSize: 12}} />
            <Tooltip contentStyle={{ backgroundColor: '#fff', borderColor: '#e2e8f0', color: '#102a43', borderRadius: '8px', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }} />
            <Legend wrapperStyle={{paddingTop: '10px'}} />
            {dataKeys.map((key, index) => (
              <Area key={key} type="monotone" dataKey={key} stroke={COLORS[index % COLORS.length]} fill={COLORS[index % COLORS.length]} fillOpacity={0.2} strokeWidth={2} />
            ))}
          </AreaChart>
        );
      case 'pie':
        return (
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip contentStyle={{ backgroundColor: '#fff', borderColor: '#e2e8f0', color: '#102a43', borderRadius: '8px' }} />
          </PieChart>
        );
      case 'line':
      default:
        return (
          <LineChart data={data} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
            <XAxis dataKey="name" stroke="#64748b" tick={{fontSize: 12}} />
            <YAxis stroke="#64748b" tick={{fontSize: 12}} />
            <Tooltip contentStyle={{ backgroundColor: '#fff', borderColor: '#e2e8f0', color: '#102a43', borderRadius: '8px', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }} />
            <Legend wrapperStyle={{paddingTop: '10px'}} />
            {dataKeys.map((key, index) => (
              <Line key={key} type="monotone" dataKey={key} stroke={COLORS[index % COLORS.length]} strokeWidth={2} dot={{r: 4, fill: COLORS[index % COLORS.length]}} activeDot={{r: 6}} />
            ))}
          </LineChart>
        );
    }
  };

  return (
    <div className="w-full bg-white p-4 rounded-xl shadow-card border border-royal-100 my-4">
      {title && <h3 className="text-lg font-bold text-royal-900 mb-4 text-center font-mono tracking-tight">{title}</h3>}
      {/* 
         Fix for warning "width(-1)": 
         Ensure the parent container has explicit width/min-width to prevent flexbox collapse issues 
         before Recharts calculates dimensions.
      */}
      <div className="h-64 w-full min-w-0 font-sans text-xs">
        <ResponsiveContainer width="100%" height="100%" minWidth={100}>
          {renderChart()}
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default ChartRenderer;