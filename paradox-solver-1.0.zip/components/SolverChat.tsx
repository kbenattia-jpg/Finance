
import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, Role } from '../types';
import { sendMessageToGemini, hasApiKey } from '../services/geminiService';
import { solveOffline, OfflineResponse } from '../services/offlineSolver';
import ChartRenderer from './ChartRenderer';
import { IconSend, IconUpload, IconFile, IconCalculator } from './Icons';
import jsPDF from 'jspdf';
import 'jspdf-autotable';

interface AttachedFile {
  data: string; // base64
  type: 'image' | 'pdf';
  name: string;
  mimeType: string;
}

const SolverChat: React.FC = () => {
  // Initialisation intelligente : Si la clé API est présente, on démarre en mode Connecté (false), sinon Offline (true)
  const [isOfflineMode, setIsOfflineMode] = useState(!hasApiKey());
  
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: Role.MODEL,
      text: hasApiKey() 
        ? "### Paradox Solver Connecté\n\nClé API détectée et active.\nJe suis prêt pour vos analyses financières avancées avec l'IA."
        : "### Paradox Solver Local\n\nPrêt pour vos calculs financiers sécurisés sur ce poste.\nSi vous n'avez pas configuré de clé API, j'utiliserai mes algorithmes internes (Mode Offline).",
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [attachedFiles, setAttachedFiles] = useState<AttachedFile[]>([]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // --- PDF EXPORT FUNCTION ---
  const exportToPdf = (message: ChatMessage) => {
    const doc: any = new jsPDF();
    
    // Header
    doc.setFillColor(16, 42, 67); // Royal Navy
    doc.rect(0, 0, 210, 25, 'F');
    doc.setFontSize(16);
    doc.setTextColor(212, 175, 55); // Gold
    doc.text("PARADOX SOLVER - RAPPORT", 105, 15, { align: 'center' });
    
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text(`Date: ${new Date().toLocaleDateString('fr-MA')}`, 15, 35);
    doc.text(`Réalisé par BENATTIA KARIM`, 15, 40);

    let yPos = 55;

    // Content Text (Split lines)
    doc.setFontSize(11);
    doc.setTextColor(0);
    
    // Clean text specifically for PDF
    const cleanText = message.text
        .replace(/###/g, '') 
        .replace(/##/g, '')
        .replace(/#/g, '')
        .replace(/\*\*/g, '') 
        .replace(/\$/g, '') 
        .replace(/\\times/g, 'x')
        .replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, '$1/$2'); 

    const splitText = doc.splitTextToSize(cleanText, 180);
    doc.text(splitText, 15, yPos);
    
    yPos += (splitText.length * 7) + 10;

    // Table rendering if exists
    if (message.tableData) {
        doc.autoTable({
            startY: yPos,
            head: [message.tableData.headers],
            body: message.tableData.rows,
            theme: 'grid',
            headStyles: { fillColor: [16, 42, 67], textColor: [255, 255, 255] },
            alternateRowStyles: { fillColor: [240, 244, 248] },
            styles: { fontSize: 9, font: 'helvetica' }
        });
    }

    // Footer
    doc.setFontSize(8);
    doc.setTextColor(150);
    doc.text("Généré par Paradox Solver - Réalisé par BENATTIA KARIM", 105, 290, { align: 'center' });

    doc.save(`paradox_sol_${Date.now()}.pdf`);
  };

  const handleSendMessage = async () => {
    if ((!inputText.trim() && attachedFiles.length === 0) || isLoading) return;

    const filesToSend = attachedFiles.map(f => ({ data: f.data, mimeType: f.mimeType }));
    
    const displayImages = attachedFiles
      .filter(f => f.type === 'image')
      .map(f => f.data);

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: Role.USER,
      text: inputText,
      timestamp: new Date(),
      images: displayImages.length > 0 ? displayImages : undefined
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setAttachedFiles([]);
    setIsLoading(true);

    let responseText = '';
    let chartData = null;
    let chartType: any = 'line';
    let chartTitle: string | undefined = undefined;
    let tableData = null;

    try {
      if (isOfflineMode) {
        // --- MODE OFFLINE FORCÉ ---
        await new Promise(r => setTimeout(r, 600)); 
        const offlineRes: OfflineResponse = solveOffline(userMessage.text);
        responseText = offlineRes.text;
        chartData = offlineRes.chartData;
        tableData = offlineRes.tableData;
      } else {
        // --- TENTATIVE MODE CONNECTÉ ---
        const aiResponse = await sendMessageToGemini(userMessage.text, filesToSend);
        
        // DÉTECTION AUTOMATIQUE DU MANQUE DE CLÉ API OU ERREUR RÉSEAU
        if (aiResponse.text === "NO_API_KEY_SIGNAL") {
             setIsOfflineMode(true);
             const offlineRes: OfflineResponse = solveOffline(userMessage.text);
             responseText = offlineRes.text + "\n\n⚠️ **Clé API non détectée.**\nJ'ai basculé en mode local. Pour activer l'IA, créez un fichier `.env` avec `REACT_APP_API_KEY` à la racine.";
             chartData = offlineRes.chartData;
             tableData = offlineRes.tableData;
        } else if (aiResponse.text === "API_ERROR_SIGNAL") {
             setIsOfflineMode(true);
             const offlineRes: OfflineResponse = solveOffline(userMessage.text);
             responseText = offlineRes.text + "\n\n*(Erreur de connexion : Calcul traité localement)*";
             chartData = offlineRes.chartData;
             tableData = offlineRes.tableData;
        } else {
            responseText = aiResponse.text;
            chartData = aiResponse.chartData;
            chartType = aiResponse.chartType || 'line';
            chartTitle = aiResponse.chartTitle;
            tableData = aiResponse.tableData;
        }
      }
    } catch (e) {
      // Fallback ultime
      const offlineRes: OfflineResponse = solveOffline(userMessage.text);
      responseText = offlineRes.text + "\n\n*(Mode de secours activé)*";
    }

    const botMessage: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: Role.MODEL,
      text: responseText,
      chartData: chartData || undefined,
      chartType: chartType,
      chartTitle: chartTitle,
      tableData: tableData || undefined,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, botMessage]);
    setIsLoading(false);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const isPdf = file.type === 'application/pdf';
        const newFile: AttachedFile = {
          data: reader.result as string,
          type: isPdf ? 'pdf' : 'image',
          name: file.name,
          mimeType: file.type
        };
        setAttachedFiles(prev => [...prev, newFile]);
      };
      reader.readAsDataURL(file);
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeFile = (index: number) => {
    setAttachedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleQuickAction = (text: string) => {
    setInputText(text);
  };

  // --- CLEANING & RENDERING ENGINE ---
  const parseInlineFormatting = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*|`.*?`)/g);
    return parts.map((part, index) => {
        if (part.startsWith('**') && part.endsWith('**')) {
            return <strong key={index} className="text-gold-600 font-bold">{part.slice(2, -2)}</strong>;
        }
        if (part.startsWith('`') && part.endsWith('`')) {
            return <code key={index} className="bg-royal-100 text-royal-800 px-1 rounded font-mono text-sm">{part.slice(1, -1)}</code>;
        }
        return <span key={index}>{part}</span>;
    });
  };

  const renderMessageText = (msg: ChatMessage) => {
    let cleanText = msg.text
      .replace(/\\times/g, ' x ')
      .replace(/\\div/g, ' ÷ ')
      .replace(/\\approx/g, ' ≈ ')
      .replace(/\\le/g, ' ≤ ')
      .replace(/\\ge/g, ' ≥ ')
      .replace(/\$([\d\s,.]+)\$/g, '$1')
      .replace(/\$/g, '') 
      .replace(/\\\[/g, '') 
      .replace(/\\\]/g, '')
      .replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, '$1/$2');

    const lines = cleanText.split('\n');

    return (
        <div className="space-y-2">
            {lines.map((line, i) => {
                const trimmedLine = line.trim();
                if (!trimmedLine) return <div key={i} className="h-2"></div>;

                if (trimmedLine.match(/^#{3}\s/)) {
                    return (
                        <h3 key={i} className="text-sm font-bold text-gold-600 uppercase tracking-widest mt-6 mb-2 pb-1 border-b border-royal-100/50">
                            {trimmedLine.replace(/^#{3}\s/, '')}
                        </h3>
                    );
                }
                if (trimmedLine.match(/^#{2}\s/)) {
                     return (
                        <h2 key={i} className="text-base font-bold text-royal-800 uppercase tracking-wide mt-6 mb-2">
                            {trimmedLine.replace(/^#{2}\s/, '')}
                        </h2>
                    );
                }
                if (trimmedLine.startsWith('* ') || trimmedLine.startsWith('- ')) {
                    const content = trimmedLine.substring(1).trim();
                    return (
                        <div key={i} className="flex items-start gap-3 ml-2 my-1">
                            <span className="text-gold-400 mt-1.5 text-[10px] flex-shrink-0">■</span>
                            <div className="text-royal-700 leading-relaxed text-sm md:text-base">
                                {parseInlineFormatting(content)}
                            </div>
                        </div>
                    );
                }
                if (trimmedLine.match(/^\d+\.\s/)) {
                    const parts = trimmedLine.split(/(\d+\.\s)(.*)/);
                    if (parts.length >= 3) {
                         return (
                            <div key={i} className="flex items-start gap-2 ml-1 my-1">
                                <span className="font-mono text-gold-600 font-bold text-sm mt-0.5">{parts[1]}</span>
                                <div className="text-royal-700 leading-relaxed text-sm md:text-base">
                                    {parseInlineFormatting(parts[2])}
                                </div>
                            </div>
                        );
                    }
                }
                return (
                    <div key={i} className="text-royal-800 leading-relaxed text-sm md:text-base mb-1">
                        {parseInlineFormatting(trimmedLine)}
                    </div>
                );
            })}

            {msg.tableData && (
                <div className="mt-6 mb-4 overflow-hidden rounded-lg shadow-card border border-royal-200">
                    <table className="financial-table w-full">
                        <thead>
                            <tr className="bg-royal-800 text-white">
                                {msg.tableData.headers.map((h: string, idx: number) => (
                                    <th key={idx} className="p-3 text-left font-bold text-xs uppercase tracking-wider text-gold-400 border-b border-gold-500/30">
                                        {h}
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {msg.tableData.rows.map((row: any[], rIdx: number) => (
                                <tr key={rIdx} className={`transition-colors hover:bg-gold-50 ${rIdx % 2 === 0 ? 'bg-white' : 'bg-royal-50/50'}`}>
                                    {row.map((cell, cIdx) => (
                                        <td key={cIdx} className="p-3 text-sm text-royal-700 border-b border-royal-100 font-mono">
                                            {cell}
                                        </td>
                                    ))}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
  };

  return (
    <div className="flex flex-col h-full bg-royal-50 font-sans">
      
      {/* Top Bar for Mode Switch */}
      <div className="bg-white px-6 py-3 border-b border-royal-100 flex justify-between items-center shadow-sm z-10">
         <div className="flex items-center gap-3">
             <div className={`w-2.5 h-2.5 rounded-full shadow-sm ${isOfflineMode ? 'bg-royal-400' : 'bg-emerald-500 animate-pulse'}`}></div>
             <div className="flex flex-col">
                <span className="text-[10px] font-bold text-royal-400 uppercase tracking-widest">Moteur</span>
                <span className={`text-xs font-bold uppercase tracking-wide ${isOfflineMode ? 'text-royal-800' : 'text-emerald-700'}`}>
                    {isOfflineMode ? 'Calcul Local (Offline)' : 'IA Connectée (Gemini)'}
                </span>
             </div>
         </div>
         <button 
           onClick={() => setIsOfflineMode(!isOfflineMode)}
           className={`text-xs px-4 py-1.5 rounded-full border font-medium transition-all shadow-sm ${isOfflineMode ? 'bg-royal-800 text-white border-royal-800 hover:bg-royal-700' : 'bg-white text-royal-600 border-royal-200 hover:border-gold-500 hover:text-gold-600'}`}
         >
           {isOfflineMode ? 'Activer IA Cloud' : 'Forcer Mode Local'}
         </button>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-8 custom-scrollbar">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === Role.USER ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[95%] md:max-w-[85%] lg:max-w-[75%] rounded-xl p-6 md:p-8 shadow-sm relative group transition-all duration-300 ${
              msg.role === Role.USER 
                ? 'bg-royal-800 text-white rounded-br-none shadow-premium' 
                : 'bg-white border border-royal-100 text-royal-900 rounded-bl-none shadow-card hover:shadow-premium'
            }`}>
              
              <div className={`absolute -top-3 ${msg.role === Role.USER ? '-right-2' : '-left-2'}`}>
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center shadow-md border ${msg.role === Role.USER ? 'bg-gold-500 border-gold-600' : 'bg-royal-900 border-royal-700'}`}>
                      <span className="text-white font-bold text-xs">{msg.role === Role.USER ? 'VOUS' : 'PS'}</span>
                  </div>
              </div>

              {msg.images && msg.images.map((img, idx) => (
                <img key={idx} src={img} alt="Upload" className="max-h-60 rounded-lg mb-6 border border-royal-200 shadow-md" />
              ))}

              <div className="font-sans whitespace-pre-wrap">
                {msg.role === Role.MODEL ? renderMessageText(msg) : msg.text}
              </div>

              {msg.chartData && (
                <div className="mt-8 bg-white p-4 rounded-xl border border-royal-100 shadow-inner">
                  <ChartRenderer 
                    data={msg.chartData} 
                    type={msg.chartType || 'line'} 
                    title={msg.chartTitle}
                    dataKeys={Object.keys(msg.chartData[0] || {}).filter(k => k !== 'name')}
                  />
                </div>
              )}

              {msg.role === Role.MODEL && (
                  <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => exportToPdf(msg)}
                        className="p-2 bg-royal-50 hover:bg-gold-50 text-royal-400 hover:text-gold-600 rounded-lg transition-colors border border-transparent hover:border-gold-200"
                        title="Exporter Rapport PDF"
                      >
                          <IconFile className="w-4 h-4" />
                      </button>
                  </div>
              )}

              <div className={`text-[10px] font-medium mt-4 pt-3 border-t ${msg.role === Role.USER ? 'border-royal-700 text-royal-400 text-right' : 'border-royal-50 text-royal-300 flex justify-between'}`}>
                {msg.role === Role.MODEL && <span>Paradox Solver • Réalisé par BENATTIA KARIM</span>}
                <span>{msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start pl-2">
            <div className="bg-white border border-royal-100 rounded-xl rounded-bl-none p-5 shadow-card flex items-center gap-4 max-w-xs">
               <div className="flex space-x-1.5">
                  <div className="w-2 h-2 bg-gold-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-royal-600 rounded-full animate-bounce delay-100"></div>
                  <div className="w-2 h-2 bg-gold-400 rounded-full animate-bounce delay-200"></div>
               </div>
               <span className="text-xs text-royal-500 font-bold uppercase tracking-wide">{isOfflineMode ? 'Calcul en cours...' : 'Analyse Expert...'}</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Actions & Input Area */}
      <div className="bg-white p-4 md:p-6 border-t border-royal-100 shadow-[0_-10px_40px_-15px_rgba(0,0,0,0.05)] z-20">
        <div className="max-w-4xl mx-auto">
          
          {/* QUICK ACTION BUTTONS */}
          <div className="flex gap-2 mb-3 overflow-x-auto pb-2 scrollbar-hide">
            <button 
              onClick={() => handleQuickAction('Emprunt 100000 4.5% 10 ans')}
              className="flex items-center gap-2 px-3 py-2 bg-royal-50 hover:bg-gold-50 text-royal-700 hover:text-gold-700 rounded-lg border border-royal-200 text-xs font-bold transition-all whitespace-nowrap"
            >
              <IconCalculator className="w-3 h-3" />
              Simuler Emprunt
            </button>
            <button 
              onClick={() => handleQuickAction('IS 450000')}
              className="flex items-center gap-2 px-3 py-2 bg-royal-50 hover:bg-gold-50 text-royal-700 hover:text-gold-700 rounded-lg border border-royal-200 text-xs font-bold transition-all whitespace-nowrap"
            >
              <IconCalculator className="w-3 h-3" />
              Calcul IS 2025
            </button>
            <button 
              onClick={() => handleQuickAction('Escompte 50000 5% 45 jours')}
              className="flex items-center gap-2 px-3 py-2 bg-royal-50 hover:bg-gold-50 text-royal-700 hover:text-gold-700 rounded-lg border border-royal-200 text-xs font-bold transition-all whitespace-nowrap"
            >
              <IconCalculator className="w-3 h-3" />
              Escompte (360j)
            </button>
             <button 
              onClick={() => handleQuickAction('VAN 100000 10% 30000 40000 50000')}
              className="flex items-center gap-2 px-3 py-2 bg-royal-50 hover:bg-gold-50 text-royal-700 hover:text-gold-700 rounded-lg border border-royal-200 text-xs font-bold transition-all whitespace-nowrap"
            >
              <IconCalculator className="w-3 h-3" />
              Calcul VAN
            </button>
          </div>

          {attachedFiles.length > 0 && (
            <div className="flex gap-3 mb-4 overflow-x-auto py-2">
              {attachedFiles.map((file, idx) => (
                <div key={idx} className="flex items-center gap-2 bg-royal-50 border border-royal-200 px-4 py-2 rounded-lg text-sm text-royal-800 shadow-sm">
                  {file.type === 'pdf' ? <IconFile className="w-4 h-4 text-red-500" /> : <span className="text-gold-500">📷</span>}
                  <span className="truncate max-w-[150px] font-medium">{file.name}</span>
                  <button onClick={() => removeFile(idx)} className="ml-2 text-royal-400 hover:text-red-500 font-bold">×</button>
                </div>
              ))}
            </div>
          )}

          <div className="flex items-end gap-3">
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="p-3.5 text-royal-500 hover:text-gold-600 hover:bg-gold-50 rounded-xl transition-all border border-transparent hover:border-gold-200"
              title="Importer Image ou PDF"
              disabled={isOfflineMode} 
            >
              <IconUpload className={`w-6 h-6 ${isOfflineMode ? 'opacity-30 cursor-not-allowed' : ''}`} />
            </button>
            <input 
              type="file" 
              ref={fileInputRef}
              className="hidden"
              accept="image/*,application/pdf"
              onChange={handleFileChange}
            />
            
            <div className="flex-1 bg-royal-50 rounded-xl border border-royal-200 focus-within:border-gold-500 focus-within:ring-1 focus-within:ring-gold-500 focus-within:bg-white transition-all shadow-inner">
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder={isOfflineMode ? "Mode Local: Tapez 'Emprunt 100000 4% 10 ans'..." : "Décrivez votre situation financière..."}
                className="w-full bg-transparent text-royal-900 p-4 max-h-32 min-h-[56px] focus:outline-none resize-none placeholder-royal-400/70 font-sans text-sm md:text-base"
                rows={1}
                style={{ height: 'auto', minHeight: '56px' }}
              />
            </div>

            <button 
              onClick={handleSendMessage}
              disabled={(!inputText.trim() && attachedFiles.length === 0) || isLoading}
              className={`p-3.5 rounded-xl transition-all shadow-lg flex-shrink-0 ${
                (!inputText.trim() && attachedFiles.length === 0) || isLoading
                  ? 'bg-royal-100 text-royal-300 cursor-not-allowed shadow-none'
                  : 'bg-royal-900 text-white hover:bg-gold-500 hover:shadow-gold-500/30 transform hover:-translate-y-0.5'
              }`}
            >
              <IconSend className="w-6 h-6" />
            </button>
          </div>
          <div className="text-center mt-3">
            <p className="text-[10px] text-royal-300 uppercase tracking-widest font-semibold">
                Paradox Solver • Réalisé par BENATTIA KARIM
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SolverChat;
