
import React from 'react';
import { MACRO_INDICATORS } from '../constants';
import { IconTrendingUp, IconTrendingDown } from './Icons';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';
import { Link } from 'react-router-dom';

const data = [
  { name: 'Jan', mad: 13200 },
  { name: 'Fév', mad: 13250 },
  { name: 'Mar', mad: 13300 },
  { name: 'Avr', mad: 13380 },
  { name: 'Mai', mad: 13410 },
  { name: 'Juin', mad: 13450 },
];

const Dashboard: React.FC = () => {
  return (
    <div className="p-6 md:p-10 space-y-8 bg-royal-50 min-h-full overflow-y-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
        <div>
          <h1 className="text-3xl font-bold text-royal-900 mb-2">Marché Financier</h1>
          <p className="text-royal-500 font-medium">Synthèse Maroc & Indicateurs Clés</p>
        </div>
        <div className="mt-4 md:mt-0 px-5 py-2 bg-white border border-gold-400/30 rounded-full text-gold-600 text-sm font-mono shadow-sm">
          ● MARCHÉ OUVERT - CASABLANCA
        </div>
      </div>

      {/* Indicators Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {MACRO_INDICATORS.map((indicator, index) => (
          <div key={index} className="bg-white border border-royal-100 rounded-xl p-6 hover:shadow-premium transition-all duration-300 shadow-card group">
            <div className="flex justify-between items-start mb-4">
              <span className="text-royal-400 text-sm font-semibold uppercase tracking-wider">{indicator.label}</span>
              {indicator.trend === 'up' ? (
                <div className="bg-emerald-50 p-1 rounded">
                   <IconTrendingUp className="w-4 h-4 text-emerald-600" />
                </div>
              ) : indicator.trend === 'down' ? (
                <div className="bg-red-50 p-1 rounded">
                   <IconTrendingDown className="w-4 h-4 text-red-500" />
                </div>
              ) : (
                <div className="w-4 h-1 bg-royal-200 mt-2"></div>
              )}
            </div>
            <div className="text-3xl font-bold text-royal-900 mb-1 font-mono tracking-tight group-hover:text-gold-600 transition-colors">{indicator.value}</div>
            <div className="text-xs text-royal-500 font-medium">{indicator.description}</div>
          </div>
        ))}
      </div>

      {/* Main Chart Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* MASI Evolution */}
        <div className="lg:col-span-2 bg-white border border-royal-100 rounded-xl p-8 shadow-card flex flex-col">
          <h3 className="text-lg font-bold text-royal-800 mb-6 flex items-center gap-2">
            <span className="w-2 h-6 bg-gold-400 rounded-sm"></span>
            Performance MASI (YTD)
          </h3>
          <div className="h-72 w-full min-w-0">
             <ResponsiveContainer width="100%" height="100%" minWidth={100}>
              <AreaChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorMad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#d4af37" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#d4af37" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis dataKey="name" stroke="#64748b" tickLine={false} axisLine={false} tick={{fill: '#475569', fontSize: 12}} />
                <YAxis stroke="#64748b" tickLine={false} axisLine={false} domain={['dataMin - 100', 'dataMax + 100']} tick={{fill: '#475569', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '8px', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                  itemStyle={{ color: '#b8860b', fontWeight: 'bold' }}
                />
                <Area type="monotone" dataKey="mad" stroke="#d4af37" strokeWidth={3} fillOpacity={1} fill="url(#colorMad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Quick Actions / News */}
        <div className="bg-royal-800 text-white border border-royal-700 rounded-xl p-8 shadow-premium flex flex-col relative overflow-hidden">
          {/* Decorative Circle */}
          <div className="absolute -top-10 -right-10 w-40 h-40 bg-white opacity-5 rounded-full pointer-events-none"></div>

          <h3 className="text-lg font-bold text-white mb-6 z-10">Flash Info Réglementaire</h3>
          <div className="space-y-5 flex-1 overflow-y-auto z-10 custom-scrollbar">
             {[
               { date: '15 Jan', title: 'Nouvelle circulaire BAM sur le risque climatique.' },
               { date: '02 Fév', title: 'PLF 2025 : Exonération TVA pour startups Tech.' },
               { date: '10 Mar', title: 'Lancement des Sukuk souverains tranche 2.' }
             ].map((news, i) => (
               <div key={i} className="group cursor-pointer">
                 <div className="text-xs font-mono text-gold-400 mb-1 opacity-80">{news.date}</div>
                 <div className="text-sm text-royal-100 font-medium leading-relaxed group-hover:text-white transition-colors border-l-2 border-royal-600 pl-3 group-hover:border-gold-400">{news.title}</div>
               </div>
             ))}
          </div>
          <div className="mt-8 pt-6 border-t border-royal-700 z-10">
            <Link to="/simulator" className="block w-full">
              <button className="w-full py-3.5 bg-gold-500 hover:bg-gold-400 text-white rounded-lg font-bold shadow-lg transition-all transform active:scale-95 flex items-center justify-center gap-2">
                <IconTrendingUp className="w-5 h-5" />
                Accéder au Simulateur
              </button>
            </Link>
          </div>
        </div>
      </div>
      
      {/* Footer Signature */}
      <div className="text-center mt-8 pb-4">
        <p className="text-[10px] text-royal-400 uppercase tracking-widest font-semibold opacity-70">
            Réalisé par BENATTIA KARIM
        </p>
      </div>
    </div>
  );
};

export default Dashboard;
