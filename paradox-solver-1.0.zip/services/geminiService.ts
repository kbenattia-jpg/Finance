
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { SYSTEM_PROMPT } from "../constants";

const apiKey = process.env.API_KEY || ''; 

export const hasApiKey = (): boolean => {
  return !!apiKey && apiKey.length > 10; // Simple validation check
};

interface ExtractedData {
  text: string;
  chartData: any[] | null;
  chartType: 'line' | 'bar' | 'area' | 'pie' | undefined;
  chartTitle: string | undefined;
  tableData: { headers: string[], rows: (string|number)[][] } | null;
}

const extractTableFromMarkdown = (text: string): { tableData: any | null, cleanText: string } => {
  const tableRegex = /(\|.*\|(?:\r?\n|\r)\|[-:| ]+\|(?:\r?\n|\r)(?:\|.*\|(?:\r?\n|\r)?)+)/;
  const match = text.match(tableRegex);

  if (!match) return { tableData: null, cleanText: text };

  try {
    const rawTable = match[0];
    const lines = rawTable.trim().split(/\r?\n/);
    const validLines = lines.filter(line => line.trim().startsWith('|'));
    
    if (validLines.length < 3) return { tableData: null, cleanText: text };

    const parseLine = (line: string): string[] => {
        let content = line.trim();
        if (content.startsWith('|')) content = content.substring(1);
        if (content.endsWith('|')) content = content.substring(0, content.length - 1);
        return content.split('|').map(c => c.trim());
    };

    const headers = parseLine(validLines[0]);
    const rows = validLines.slice(2).map(line => {
      const cells = parseLine(line);
      if (cells.length > headers.length) return cells.slice(0, headers.length);
      while (cells.length < headers.length) cells.push('');
      return cells.map(val => {
          const num = parseFloat(val.replace(/\s/g, '').replace(',', '.'));
          return (val !== '' && !isNaN(num) && /[\d]/.test(val)) ? num : val;
        });
    });

    if (rows.length > 0) {
      return {
        tableData: { headers, rows },
        cleanText: text.replace(rawTable, '').trim()
      };
    }
  } catch (e) {
    console.error("Error parsing markdown table", e);
  }
  return { tableData: null, cleanText: text };
};

const extractJsonFromResponse = (text: string): ExtractedData => {
  const chartBlockRegex = /```json-chart([\s\S]*?)```/;
  const match = text.match(chartBlockRegex);
  
  let chartData: any[] | null = null;
  let chartType: any = undefined;
  let chartTitle: string | undefined = undefined;
  let textAfterChart = text;

  if (match && match[1]) {
    try {
      const parsed = JSON.parse(match[1].trim());
      if (parsed.data && Array.isArray(parsed.data)) {
        chartData = parsed.data;
        chartType = parsed.type;
        chartTitle = parsed.title;
      } else if (Array.isArray(parsed)) {
        chartData = parsed;
        chartType = 'line';
      }
      textAfterChart = text.replace(match[0], '').trim();
    } catch (e) {
      console.error("Failed to parse chart JSON", e);
    }
  }

  const { tableData, cleanText } = extractTableFromMarkdown(textAfterChart);

  return { text: cleanText, chartData, chartType, chartTitle, tableData };
};

export const sendMessageToGemini = async (
  prompt: string,
  files: { data: string, mimeType: string }[] = [] 
): Promise<ExtractedData> => {
  // 1. Vérification stricte de la clé API
  if (!hasApiKey()) {
    console.warn("⚠️ Clé API introuvable. Assurez-vous d'avoir configuré l'environnement avec API_KEY.");
    return {
      text: "NO_API_KEY_SIGNAL", // Déclenche le mode hors-ligne dans SolverChat
      chartData: null,
      chartType: undefined,
      chartTitle: undefined,
      tableData: null
    };
  }

  const ai = new GoogleGenAI({ apiKey });

  try {
    const parts: any[] = [];
    files.forEach(file => {
      const base64Data = file.data.split(',')[1] || file.data;
      parts.push({
        inlineData: {
          mimeType: file.mimeType, 
          data: base64Data
        }
      });
    });

    parts.push({ text: prompt });

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash', 
      contents: { role: 'user', parts },
      config: {
        systemInstruction: SYSTEM_PROMPT,
        temperature: 0.1, 
        topK: 32,
        topP: 0.95,
      }
    });

    const fullText = response.text || "Erreur de génération.";
    return extractJsonFromResponse(fullText);

  } catch (error) {
    console.error("Gemini API Error:", error);
    return {
      text: "API_ERROR_SIGNAL", 
      chartData: null,
      chartType: undefined,
      chartTitle: undefined,
      tableData: null
    };
  }
};
