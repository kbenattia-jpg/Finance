

// Moteur de calcul financier Offline - Paradox Solver
// Sans IA, basé sur des algorithmes déterministes et les règles fiscales Maroc 2025.

export interface OfflineResponse {
  text: string;
  tableData?: { headers: string[], rows: (string|number)[][] };
  chartData?: any[];
}

// Format number to currency
const fmt = (n: number) => new Intl.NumberFormat('fr-MA', { maximumFractionDigits: 2, minimumFractionDigits: 2 }).format(n);

/**
 * Détecte l'intention de l'utilisateur et route vers le bon calculateur
 */
export const solveOffline = (input: string): OfflineResponse => {
  const cleanInput = input.toLowerCase().trim();

  // 1. CALCUL EMPRUNT / CRÉDIT
  if (cleanInput.includes('emprunt') || cleanInput.includes('credit') || cleanInput.includes('prêt')) {
    return calculateLoan(cleanInput);
  }

  // 2. CALCUL IS (IMPÔT SOCIÉTÉ)
  if (cleanInput.includes('is') || cleanInput.includes('impot') || cleanInput.includes('fiscal')) {
    return calculateIS(cleanInput);
  }

  // 3. CALCUL VAN (Investissement)
  if (cleanInput.includes('van') || cleanInput.includes('projet')) {
    return calculateVAN(cleanInput);
  }
  
  // 4. CALCUL ESCOMPTE / AGIOS (Base 360)
  if (cleanInput.includes('escompte') || cleanInput.includes('agios') || cleanInput.includes('effet')) {
    return calculateEscompte(cleanInput);
  }

  // 5. INTÉRÊTS SIMPLES (Base 360 générique)
  if (cleanInput.includes('interet') && (cleanInput.includes('simple') || cleanInput.includes('placement'))) {
    return calculateSimpleInterest(cleanInput);
  }

  return {
    text: "**Mode Offline - Guide des Commandes (Norme 360 jours):**\n\n" +
          "Je respecte strictement l'année commerciale bancaire (360j) pour tous les calculs de jours.\n\n" +
          "1. **Emprunt** : Tapez `Emprunt [Montant] [Taux] [Durée]`\n" +
          "   *Ex: Emprunt 100000 5% 5 ans*\n\n" +
          "2. **Escompte / Agios (360j)** : Tapez `Escompte [Valeur] [Taux] [Jours]`\n" +
          "   *Ex: Escompte 50000 8% 45 jours*\n\n" +
          "3. **Intérêts Simples (360j)** : Tapez `Interet simple [Capital] [Taux] [Jours]`\n" +
          "   *Ex: Interet simple 20000 4% 90 jours*\n\n" +
          "4. **Impôt IS** : Tapez `IS [Résultat Fiscal]`\n" +
          "   *Ex: IS 450000*\n\n" +
          "5. **VAN** : Tapez `VAN [Investissement] [Taux] [Flux1] [Flux2]...`\n" +
          "   *Ex: VAN 100000 10% 30000 40000 50000*"
  };
};

/**
 * Calculateur d'Emprunt (Amortissement Constant vs Annuité Constante)
 * Utilise la logique mensuelle standard (compatible 30/360)
 */
const calculateLoan = (input: string): OfflineResponse => {
  // Extraction des chiffres : Montant, Taux, Durée
  const numbers = input.match(/[\d\.,]+/g);
  if (!numbers || numbers.length < 3) {
    return { text: "⚠️ Données manquantes. Format: `Emprunt 100000 5% 5 ans`" };
  }

  const K = parseFloat(numbers[0].replace(',', '.')); // Capital
  const t_raw = parseFloat(numbers[1].replace(',', '.')); // Taux annuel
  const n = parseFloat(numbers[2].replace(',', '.')); // Durée (années)

  if (isNaN(K) || isNaN(t_raw) || isNaN(n)) return { text: "Erreur de lecture des nombres." };

  const t = t_raw / 100;
  const im = t / 12; // Taux mensuel (Standard bancaire, équivalent 30/360)
  const durationMonths = n * 12;

  // Calcul Annuité Constante (Formule standard)
  const a = K * (im / (1 - Math.pow(1 + im, -durationMonths)));
  
  const totalCost = (a * durationMonths) - K;

  // Génération du tableau d'amortissement (simplifié annuel pour l'affichage chat)
  const tableRows: (string|number)[][] = [];
  let k_restant = K;
  let interet_total = 0;
  
  // On affiche année par année pour ne pas saturer le chat
  for (let i = 1; i <= n; i++) {
    let interet_annuel = 0;
    let amortissement_annuel = 0;
    let annuite_annuelle = 0;

    // Simulation mensuelle agrégée
    for (let m = 0; m < 12; m++) {
        const interet = k_restant * im;
        const amort = a - interet;
        k_restant -= amort;
        interet_annuel += interet;
        amortissement_annuel += amort;
    }
    annuite_annuelle = interet_annuel + amortissement_annuel;
    interet_total += interet_annuel;

    tableRows.push([
      i,
      fmt(annuite_annuelle),
      fmt(interet_annuel),
      fmt(amortissement_annuel),
      fmt(k_restant > 0 ? k_restant : 0)
    ]);
  }

  return {
    text: `**Résultat Simulation Emprunt (Mode Expert Offline)**\n\n` +
          `• Capital : **${fmt(K)} MAD**\n` +
          `• Taux Annuel : **${t_raw}%**\n` +
          `• Durée : **${n} ans**\n` +
          `• Mensualité : **${fmt(a)} MAD**\n` +
          `• Coût Total Crédit : **${fmt(totalCost)} MAD**\n\n` +
          `*Note: Calculs basés sur l'amortissement mensuel standard.*`,
    tableData: {
      headers: ["Année", "Annuité", "Intérêts", "Amortissement", "Capital Restant"],
      rows: tableRows
    },
    chartData: [
      { name: 'Capital', value: K },
      { name: 'Intérêts', value: parseFloat(totalCost.toFixed(2)) }
    ]
  };
};

/**
 * Calculateur d'Escompte / Agios (Base 360 jours STRICTE)
 * E = (V * t * n) / 36000
 */
const calculateEscompte = (input: string): OfflineResponse => {
    // Ex: Escompte 50000 8% 45 jours
    const numbers = input.match(/[\d\.,]+/g);
    if (!numbers || numbers.length < 3) {
        return { text: "⚠️ Données manquantes. Format: `Escompte [Valeur Nominale] [Taux] [Jours]`" };
    }

    const V = parseFloat(numbers[0].replace(',', '.')); // Valeur Nominale
    const t = parseFloat(numbers[1].replace(',', '.')); // Taux Annuel
    const n = parseFloat(numbers[2].replace(',', '.')); // Nombre de jours

    if (isNaN(V) || isNaN(t) || isNaN(n)) return { text: "Erreur de format numérique." };

    // Formule Commerciale (Base 360 STRICTE)
    // Divisé par 36000 car t est en pourcentage absolu (ex: 8 pour 8%)
    const e = (V * t * n) / 36000;
    const valeurNette = V - e;

    return {
        text: `**Calcul d'Escompte Commercial (Base 360j)**\n\n` +
              `• Valeur Nominale : **${fmt(V)} MAD**\n` +
              `• Taux d'Escompte : **${t}%**\n` +
              `• Durée : **${n} jours** / 360 (Année Commerciale)\n` +
              `• **Montant de l'Escompte : ${fmt(e)} MAD**\n` +
              `• Valeur Nette : **${fmt(valeurNette)} MAD**\n\n` +
              `✅ **Conforme Norme Bancaire (360 jours)**.`,
        tableData: {
            headers: ["Paramètre", "Valeur"],
            rows: [
                ["Valeur Nominale", fmt(V)],
                ["Taux", t + "%"],
                ["Jours (Base 360)", n.toString()],
                ["Escompte", fmt(e)],
                ["Valeur Nette", fmt(valeurNette)]
            ]
        }
    };
};

/**
 * Calculateur d'Intérêts Simples (Base 360 jours STRICTE)
 * I = (C * t * n) / 36000
 */
const calculateSimpleInterest = (input: string): OfflineResponse => {
    // Ex: Interet simple 20000 4% 90 jours
    const numbers = input.match(/[\d\.,]+/g);
    if (!numbers || numbers.length < 3) {
        return { text: "⚠️ Données manquantes. Format: `Interet simple [Capital] [Taux] [Jours]`" };
    }

    const C = parseFloat(numbers[0].replace(',', '.')); // Capital
    const t = parseFloat(numbers[1].replace(',', '.')); // Taux Annuel
    const n = parseFloat(numbers[2].replace(',', '.')); // Jours

    // Formule Intérêt Simple Base 360
    const interet = (C * t * n) / 36000;
    const valeurFinale = C + interet;

    return {
        text: `**Calcul d'Intérêts Simples (Base 360j)**\n\n` +
              `• Capital : **${fmt(C)} MAD**\n` +
              `• Taux Annuel : **${t}%**\n` +
              `• Durée : **${n} jours** / 360\n` +
              `• **Intérêts Générés : ${fmt(interet)} MAD**\n` +
              `• Valeur Acquise : **${fmt(valeurFinale)} MAD**\n\n` +
              `✅ **Règle : Prorata Temporis sur année commerciale 360 jours.**`,
        tableData: {
            headers: ["Paramètre", "Valeur"],
            rows: [
                ["Capital", fmt(C)],
                ["Taux", t + "%"],
                ["Jours", n.toString()],
                ["Base Annuelle", "360 jours"],
                ["Intérêts", fmt(interet)]
            ]
        }
    };
};

/**
 * Calculateur IS (Impôt sur les Sociétés) - Barème Maroc 2025
 */
const calculateIS = (input: string): OfflineResponse => {
  const numbers = input.match(/[\d\.,\s]+/g);
  if (!numbers) return { text: "Indiquez le Résultat Fiscal. Ex: `IS 400000`" };

  const rfStr = numbers[0].replace(/\s/g, '').replace(',', '.');
  const rf = parseFloat(rfStr); // Résultat Fiscal

  if (isNaN(rf)) return { text: "Erreur de format du montant." };

  let is_theorique = 0;
  let details = "";
  let taux_marginal = "";

  // Barème progressif 2025
  if (rf <= 300000) {
    is_theorique = rf * 0.10;
    taux_marginal = "10%";
    details = `• Tranche < 300k : ${fmt(rf)} x 10% = ${fmt(is_theorique)}`;
  } else if (rf <= 1000000) {
    const part1 = 300000 * 0.10;
    const part2 = (rf - 300000) * 0.20;
    is_theorique = part1 + part2;
    taux_marginal = "20%";
    details = `• Tranche < 300k : 300,000 x 10% = ${fmt(part1)}\n` +
              `• Tranche 300k-1M : ${fmt(rf - 300000)} x 20% = ${fmt(part2)}`;
  } else {
    const part1 = 300000 * 0.10;
    const part2 = 700000 * 0.20;
    const part3 = (rf - 1000000) * 0.31; // Taux 31% cible 2025
    is_theorique = part1 + part2 + part3;
    taux_marginal = "31%";
    details = `• Tranche < 300k : 300,000 x 10% = ${fmt(part1)}\n` +
              `• Tranche 300k-1M : 700,000 x 20% = ${fmt(part2)}\n` +
              `• Tranche > 1M : ${fmt(rf - 1000000)} x 31% = ${fmt(part3)}`;
  }

  return {
    text: `**Calcul de l'IS (Barème Progressif 2025)**\n\n` +
          `Résultat Fiscal : **${fmt(rf)} MAD**\n\n` +
          `**Détail du calcul :**\n${details}\n\n` +
          `**IS À PAYER : ${fmt(is_theorique)} MAD**\n` +
          `*(Taux marginal atteint : ${taux_marginal})*\n\n` +
          `*Note : N'oubliez pas de vérifier la Cotisation Minimale (0.25% du CA) si elle est supérieure à l'IS calculé.*`,
    tableData: {
      headers: ["Base Imposable", "Taux", "Montant IS"],
      rows: [
        [fmt(rf), taux_marginal, fmt(is_theorique)]
      ]
    }
  };
};

/**
 * Calcul VAN (Valeur Actuelle Nette)
 * VAN = -I0 + Sum(CF / (1+t)^i)
 */
const calculateVAN = (input: string): OfflineResponse => {
    // Ex: VAN 100000 10% 30000 40000 50000
    const numbers = input.match(/[\d\.,]+/g);
    if (!numbers || numbers.length < 3) {
        return { text: "⚠️ Format invalide. Tapez: `VAN [Investissement] [Taux] [Flux1] [Flux2]...`" };
    }

    const I0 = parseFloat(numbers[0].replace(',', '.'));
    const taux = parseFloat(numbers[1].replace(',', '.')) / 100;
    
    let van = -I0;
    const tableRows = [];
    tableRows.push(["0 (Invest.)", fmt(-I0), "1.000", fmt(-I0)]);

    for (let i = 2; i < numbers.length; i++) {
        const cf = parseFloat(numbers[i].replace(',', '.'));
        const annee = i - 1;
        const coef = Math.pow(1 + taux, -annee);
        const cf_actu = cf * coef;
        van += cf_actu;
        
        tableRows.push([
            annee.toString(),
            fmt(cf),
            coef.toFixed(4),
            fmt(cf_actu)
        ]);
    }

    const isProfitable = van > 0;

    return {
        text: `**Analyse de Projet d'Investissement**\n\n` +
              `• Investissement Initial : **${fmt(I0)} MAD**\n` +
              `• Taux d'actualisation : **${(taux*100).toFixed(2)}%**\n` +
              `• **VAN (Valeur Actuelle Nette) : ${fmt(van)} MAD**\n\n` +
              `**Conclusion :** Le projet est ${isProfitable ? "✅ RENTABLE" : "❌ NON RENTABLE"} car la VAN est ${isProfitable ? "positive" : "négative"}.`,
        tableData: {
            headers: ["Année", "Flux Trésorerie", "Coef. Actu", "Flux Actualisé"],
            rows: tableRows
        }
    };
};