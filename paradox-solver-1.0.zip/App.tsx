
import React, { useState } from 'react';
import { HashRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import Dashboard from './components/Dashboard';
import SolverChat from './components/SolverChat';
import FinancialSimulator from './components/FinancialSimulator';
import ScientificCalculator from './components/ScientificCalculator'; 
import { IconHome, IconChat, IconCalculator, IconMenu, IconCalculatorScientific, IconFile } from './components/Icons';
import { APP_NAME } from './constants';

const SidebarLink = ({ to, icon: Icon, label, isActive, onClick }: any) => (
  <Link
    to={to}
    onClick={onClick}
    className={`flex items-center space-x-3 px-4 py-3.5 rounded-lg transition-all duration-200 group ${
      isActive 
        ? 'bg-royal-800 text-white shadow-lg shadow-royal-900/20 border-l-4 border-gold-500' 
        : 'text-royal-400 hover:bg-white hover:text-royal-800 hover:shadow-sm'
    }`}
  >
    <Icon className={`w-5 h-5 ${isActive ? 'text-gold-400' : 'group-hover:text-royal-600'}`} />
    <span className="font-semibold tracking-wide">{label}</span>
  </Link>
);

const AppContent = () => {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="flex h-screen bg-royal-50 overflow-hidden font-sans text-royal-900">
      
      {/* Sidebar for Desktop */}
      <aside className="hidden md:flex flex-col w-72 bg-royal-50 border-r border-royal-200/60">
        <div className="p-8 pb-4">
          <div className="flex items-center gap-3 mb-1">
             <div className="w-10 h-10 bg-royal-900 rounded-xl flex items-center justify-center shadow-premium">
               <span className="text-gold-400 font-bold text-2xl font-mono">P</span>
             </div>
             <div>
               <h1 className="text-royal-900 font-extrabold tracking-tight text-xl leading-none">{APP_NAME}</h1>
               <div className="text-[10px] text-royal-500 font-bold tracking-[0.2em] uppercase mt-1">Installation Locale</div>
             </div>
          </div>
        </div>
        
        <nav className="flex-1 px-4 py-6 space-y-2">
          <div className="px-4 text-xs font-bold text-royal-400 uppercase tracking-wider mb-2">Menu Principal</div>
          <SidebarLink to="/" icon={IconHome} label="Tableau de Bord" isActive={location.pathname === '/'} />
          <SidebarLink to="/solver" icon={IconChat} label="Assistant Financier" isActive={location.pathname === '/solver'} />
          <SidebarLink to="/simulator" icon={IconCalculator} label="Simulateur Prêt" isActive={location.pathname === '/simulator'} />
          <SidebarLink to="/calculator" icon={IconCalculatorScientific} label="Calculatrice Scientifique" isActive={location.pathname === '/calculator'} />
        </nav>

        <div className="p-6 border-t border-royal-200/50">
          <div className="bg-white rounded-xl p-4 border border-royal-100 shadow-card">
            <div className="text-[10px] font-bold text-royal-400 uppercase mb-2">Environnement</div>
            <div className="flex items-center space-x-2">
              <IconFile className="w-4 h-4 text-royal-600" />
              <span className="text-xs font-bold text-royal-700">Stockage Local</span>
            </div>
             <div className="text-[10px] text-royal-400 mt-1 pl-6">
                Aucune donnée n'est envoyée vers un serveur central.
            </div>
            <div className="text-[10px] text-royal-400 mt-3 pt-2 border-t border-royal-100 font-medium">
                Réalisé par BENATTIA KARIM
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 w-full bg-white border-b border-royal-100 z-50 flex items-center justify-between p-4 shadow-sm">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-royal-900 rounded-lg flex items-center justify-center">
              <span className="text-gold-400 font-bold">P</span>
          </div>
          <span className="text-royal-900 font-bold text-lg">{APP_NAME}</span>
        </div>
        <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="text-royal-600">
          <IconMenu className="w-7 h-7" />
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 bg-white z-40 pt-20 px-4 md:hidden">
           <nav className="space-y-4">
            <SidebarLink to="/" icon={IconHome} label="Tableau de Bord" isActive={location.pathname === '/'} onClick={() => setMobileMenuOpen(false)} />
            <SidebarLink to="/solver" icon={IconChat} label="Assistant" isActive={location.pathname === '/solver'} onClick={() => setMobileMenuOpen(false)} />
            <SidebarLink to="/simulator" icon={IconCalculator} label="Simulateur" isActive={location.pathname === '/simulator'} onClick={() => setMobileMenuOpen(false)} />
            <SidebarLink to="/calculator" icon={IconCalculatorScientific} label="Calculatrice" isActive={location.pathname === '/calculator'} onClick={() => setMobileMenuOpen(false)} />
            
            <div className="mt-8 pt-8 border-t border-royal-100 text-center">
                <p className="text-xs font-bold text-royal-400 uppercase">Réalisé par BENATTIA KARIM</p>
            </div>
          </nav>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 md:h-screen overflow-hidden pt-16 md:pt-0">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/solver" element={<SolverChat />} />
          <Route path="/simulator" element={<FinancialSimulator />} />
          <Route path="/calculator" element={<ScientificCalculator />} />
        </Routes>
      </main>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <Router>
      <AppContent />
    </Router>
  );
};

export default App;
